namespace Enums;
public enum Category
{
    Pants = 0,
    Shirts = 1,
    Shoes = 2,
    Underwear = 3,
    Sweatshirts = 4,
    Jackets = 5,
    Sportswear = 6,
    Dresses = 7,
    Skirts = 8,
    Other = 9
}