namespace Enums;

public enum Color
{
    White = 0,
    Red = 1,
    Green = 2,
    Blue = 3,
    Yellow = 4,
    Beige = 5,
    Purple = 6,
    Pink = 7,
    Black = 8,
    Gray = 9
}